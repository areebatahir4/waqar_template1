<div class="separator" style="clear: both; text-align: center;">
<a href="http://2.bp.blogspot.com/-olP4cHNbfjI/Ua9sGe-AW8I/AAAAAAAAN7Q/Ggf3aTc685E/s1600/lermais.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://2.bp.blogspot.com/-olP4cHNbfjI/Ua9sGe-AW8I/AAAAAAAAN7Q/Ggf3aTc685E/s1600/lermais.png" /></a></div>
<br />